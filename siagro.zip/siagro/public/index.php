<?php

define('ROOT', dirname(__DIR__) . DIRECTORY_SEPARATOR);

define('APP', ROOT . 'aplicacao' . DIRECTORY_SEPARATOR);

require APP . 'config/config.php';

// Carregar as classes base da aplicacao 

require APP . 'registros/aplicacao.php';
require APP . 'registros/controller.php';
require APP . 'registros/bd.php';

// começar a aplicacao
$app = new aplicacao();
