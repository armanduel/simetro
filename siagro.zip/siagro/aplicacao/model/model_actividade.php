<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 */

/**
 * Description of model Usuario
 *
 * @author Armando Manuel
 */

class model_actividade extends bd{
    
    public static function selecionar_actividades(){
                
        $actividades = []; 
        $bd=new bd();
        $actividades = $bd->tabela('actividade')->colher()->paraArray();
        
        return $actividades;   
       
    }

    public static function criar_actividade($dados) {  // Armando
	    $bd = New bd();
            $actividade = $bd->inserir('actividade',[
                                'descricao' => $dados['descricao'], 
                                'actividade_categoria_id' => $dados['actividade_catgoria_id'],                                
                                'lote_id' => $dados['lote_id'],
                                'area_id' => $dados['area_id'],
                                'lavra_id' => $dados['lavra_id'], 
                                'data_inicio' => $dados['data_inicio'],
                                'data_fim' => $dados['data_fim'],  
                                'criado_em' => $dados['criado_em'],
                                'criado_por' => $dados['criado_por'],                
                                'estado' => $dados['estado'],
                                'custo' => $dados['custo'],  
                                'comentario' => $dados['comentario'],          
                               ]);

            if ( $actividade ) {
                    $id = $actividade;			
            } else {
                    $id = 0;
            }
        return $id;
        
    }

    public static function editar_actividade($dados) {
			
        if (!isset($dados['id'])){
            return false;
		}				
                $bd = New bd();		
		$actividade = $bd->editar('actividade',
                                [                                    
                                'descricao' => $dados['descricao'], 
                                'actividade_categoria_id' => $dados['actividade_catgoria_id'],                                
                                'lote_id' => $dados['lote_id'],
                                'area_id' => $dados['area_id'],
                                'lavra_id' => $dados['lavra_id'], 
                                'data_inicio' => $dados['data_inicio'],
                                'data_fim' => $dados['data_fim'],  
                                'criado_em' => $dados['criado_em'],
                                'criado_por' => $dados['criado_por'],                
                                'estado' => $dados['estado'],
                                'custo' => $dados['custo'],  
                                'comentario' => $dados['comentario']  
                                ])->onde('id',$dados['id'])->exec(); 
		//echo $bd->lastId();				
		if ( $actividade ) {
			$id = $actividade;			
		} else {
			$id = 0;
		}
        return $id;		
    }
    
    public static function editar_actividades( $dados) {  // Armando

        foreach ($dados as $actividade) {

                if($actividade['id']==""){
                    
                    $resultados = self::criar_actividade($actividade);

                 } else {
                     
                    $resultados = self::editar_actividade($actividade);

                 }
           }
            
          return $resultados; 
          
} 
    public static function excluir_actividade( $id) {//Armando

            $bd = New bd();
            $resultados= $bd->excluir('actividade')->onde('id',$id)->exec();		
            return $resultados;
    }
    public static function excluir_actividades($coluna, $coluna_valor) {

            $bd= new bd();
            $resultados = $bd->excluir('actividade')->onde($coluna, $coluna_valor)->exec();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }      

    public static function selecionar_actividades_filtro($coluna, $coluna_valor, $ordem='id', $ordem_tipo ='ASC') {

            $bd= new bd();
            $resultados = $bd->tabela('actividade')->onde($coluna, $coluna_valor)->ordenarPor('ordem', 'ASC')->colher();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }


    public static function selecionar_actividade_id( $id ) { // Armando
            $bd= new bd();
            $resultados =$bd->tabela('actividade')->onde($id)->colher()->paraArray();//;
            //$resultados = json_decode(json_encode($resultados), true);
            return $resultados;
    }
    
    public static function selecionar_actividade_categoria( $categoria ) { // Armando
        $bd= new bd();
        $resultados =$bd->tabela('actividade')->onde('actividade_categoria_id', $categoria)->colher();
        $resultados = json_decode(json_encode($resultados), true);
      
        return $resultados;           
    }  
       
    public static function consulta_sql($consulta){
        $actividades = []; 
        $bd=new bd();
        $actividades = $bd->consulta($consulta);
        return $actividades;
    }
    
    public static function total_actividade(){
        
        $total ="0";
        
        $bd=new bd();
        $total = $bd->contar();
        return $total;
    }
}
