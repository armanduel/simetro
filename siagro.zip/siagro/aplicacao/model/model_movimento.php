<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 */

/**
 * Description of model Usuario
 *
 * @author Armando Manuel
 */

class model_movimento extends bd{
    
    public static function selecionar_movimentos(){
                
        $movimentos = []; 
        $bd=new bd();
        $movimentos = $bd->tabela('movimento')->colher()->paraArray();
        
        return $movimentos;   
       
    }

    public static function criar_movimento($dados) {  // Armando
	    $bd = New bd();
            $movimento = $bd->inserir('movimento',[
                                'descricao' => $dados['descricao'], 
                                'movimento_tipo_id' => $dados['movimento_tipo_id'],                                
                                'categoria' => $dados['categoria'], 
                                'quantidade' => $dados['quantidade'],
                                'unidade' => $dados['unidade'],  
                                'data' => $dados['data'], 
                                'estado' => $dados['estado'],
                                'criado_em' => $dados['criado_em'],  
                                'criaddo_por' => $dados['criaddo_por']                            
                                             
                    ]);

            if ( $movimento ) {
                    $id = $movimento;			
            } else {
                    $id = 0;
            }
        return $id;
        
    }

    public static function editar_movimento($dados) {
			
        if (!isset($dados['id'])){
            return false;
		}				
                $bd = New bd();		
		$movimento = $bd->editar('movimento',
                                [  
                                'descricao' => $dados['descricao'], 
                                'movimento_tipo_id' => $dados['movimento_tipo_id'],                                
                                'categoria' => $dados['categoria'], 
                                'quantidade' => $dados['quantidade'],
                                'unidade' => $dados['unidade'],  
                                'data' => $dados['data'], 
                                'estado' => $dados['estado'],
                                'criado_em' => $dados['criado_em'],  
                                'criaddo_por' => $dados['criaddo_por']
                                ])->onde('id',$dados['id'])->exec(); 
		//echo $bd->lastId();				
		if ( $movimento ) {
			$id = $movimento;			
		} else {
			$id = 0;
		}
        return $id;		
    }
    
    public static function editar_movimentos( $dados) {  // Armando

        foreach ($dados as $movimento) {

                if($movimento['id']==""){
                    
                    $resultados = self::criar_movimento($movimento);

                 } else {
                     
                    $resultados = self::editar_movimento($movimento);

                 }
           }
            
          return $resultados; 
          
} 
    public static function excluir_movimento( $id) {//Armando

            $bd = New bd();
            $resultados= $bd->excluir('movimento')->onde('id',$id)->exec();		
            return $resultados;
    }
    public static function excluir_movimentos($coluna, $coluna_valor) {

            $bd= new bd();
            $resultados = $bd->excluir('movimento')->onde($coluna, $coluna_valor)->exec();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }      

    public static function selecionar_movimentos_filtro($coluna, $coluna_valor, $ordem='id', $ordem_tipo ='ASC') {

            $bd= new bd();
            $resultados = $bd->tabela('movimento')->onde($coluna, $coluna_valor)->ordenarPor('ordem', 'ASC')->colher();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }


    public static function selecionar_movimento_id( $id ) { // Armando
            $bd= new bd();
            $resultados =$bd->tabela('movimento')->onde($id)->colher()->paraArray();//;
            //$resultados = json_decode(json_encode($resultados), true);
            return $resultados;
    }
    
    public static function selecionar_movimento_categoria( $categoria ) { // Armando
        $bd= new bd();
        $resultados =$bd->tabela('movimento')->onde('categoria', $categoria)->colher();
        $resultados = json_decode(json_encode($resultados), true);
      
        return $resultados;           
    }  
       
    public static function consulta_sql($consulta){
        $movimentos = []; 
        $bd=new bd();
        $movimentos = $bd->consulta($consulta);
        return $movimentos;
    }
    
    public static function total_movimento(){
        
        $total ="0";
        
        $bd=new bd();
        $total = $bd->contar();
        return $total;
    }
}
