<?php


class model_form_itens extends bd{
    

    public static function pegar_itens(){
                
        $itens = []; 
        $bd=new bd();
        $itens = $bd->table('mytable')->get()->toArray();
        
        return itens;   
       
    }

    public static function adicionar_item($form_id,$dados) {  // Armando
	
            $dados = $dados;

            $bd = New bd();
            $item = $bd->insert('form_itens',
                    [
                            'nome' => $dados['nome'],
                            'tipo' => $dados['tipo'],				
                            'ordem'=> $dados['ordem'],
                            'form_id'=> $form_id
                    ]);

            if ( $item ) {
                    $insert_id = $item;			
            } else {
                    $insert_id = 0;
            }
        return $insert_id;
        
    }

    public static function actualizar_dados($form_id, $dados) {
	$dados = $dados;

        
        if ( ! $form_id ) {
            return false;
		}				
                $bd = New bd();		
		$item = $bd->update('form_itens',[                    
                                'descricao' => $dados['descricao'],
                                'opcoes' => $dados['opcoes'],
                                'pre_definido' => $dados['pre_definido'],				
                                'obrigatorio'=> $dados['obrigatorio'],
                                'form_id'=> $form_id
                                ])->where('id',$dados['id'])->exec(); 
		//echo $bd->lastId();				
		if ( $item ) {
			$insert_id = $item;			
		} else {
			$insert_id = 0;
		}
        return $insert_id;		
    }	
	
    public static function actualizar_campo($form_id, $dados) {
	$dados = $dados;

        
        if ( ! $form_id ) {
            return false;
		}				
                $bd = New bd();		
		$item = $bd->update('form_itens',[
                                'nome' => $dados['nome'],
                                'tipo' => $dados['tipo'],				
                                'ordem'=> $dados['ordem'],
                                'form_id'=> $form_id
                                ])->where('id',$dados['id'])->exec(); 
		//echo $bd->lastId();				
		if ( $item ) {
			$insert_id = $item;			
		} else {
			$insert_id = 0;
		}
        return $insert_id;		
    }		
	/**
     * 
     */	
    public static function actualizar_campos( $form_id, $input) {  // Armando

        foreach ($input as $dados) {

                if($dados['id']==""){
                    
                    $resultados = self::adicionar_item($form_id,$dados);

                 } else {
                     
                    $resultados = self::actualizar_campo($form_id, $dados);

                 }
           }
            
             //return $resultados; 
    
} 
    public static function apagar_campo( $id) {//Armando

            $bd = New bd();
            $resultados= $bd->delete('form_itens')->where('id',$id)->exec();		
            return $resultados;
    }

    public static function selecionar_campos($form_id) {

            $bd= new bd();
            $resultados = $bd->table('form_itens')->where('form_id',$form_id)->orderBy('ordem', 'ASC')->get();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($results);
            return $resultados;
    }

    public static function selecionar_campo( $id ) { // Armando
            $bd= new bd();
            $resultados =$bd->table('form_itens')->where($id)->get();//;
            $resultados = json_decode(json_encode($resultados), true);
            //print_r ($results);
            return $resultados;
    }

    
    public static function dados_html($form_id){
        
        
        $dados = self::selecionar_campos($form_id);
        
        $html = "";
        
        foreach ($dados as $item){
            
        $id =$item['id'];
        $nome =$item['nome'];
        $descricao =$item['descricao'];
        $tipo =$item['tipo'];
        $opcoes =$item['opcoes'];
        $pre_definido =$item['pre_definido'];
        $form_id =$item['form_id'];
        $obrigatorio =$item['obrigatorio'];
        $ordem =$item['ordem'];
            
            $html .='
            <li class="form-group row" c_type="'.$tipo.'">						
                <div class="col-sm-5 ">
                        <input type="text" name="label-'.$id.'" placeholder="escreva o nome do campo" field_type="'.$tipo.'" id="'.$id.'" class="form-control novo" align="right" value="'.$nome.'"/>
                </div>
                <div class="col-sm-6">';                    
                    
            switch ($item['tipo']) {
                case "text":
                    $html .='<input type="text" name="text-'.$id.'" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                case "radio":
                   $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                   break;
                case "file":
                    $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                case "checkbox":
                    $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                case "select":
                    $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                case "multi_select":
                    $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                case "text_area":
                    $html .='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';
                    break;
                default:
                    echo "";
            }         
            
            $html .='
                    </div>
            <div class="col-sm-1">
                    <button type="button" name="remove" data-row="row" class="btn btn-danger btn-xs remove" id="'.$id.'">-</button>      
                    <button type="button" name="save" id="'.$id.'" data-row="row1" class="btn btn-success btn-xs editar">+</button>
            </div>
        </li>';
            
           // print_r($item);
            //exit();
        }
        
        return $html;
                
    }
 
    
    public static function html_text($item){
        $html ="";
        
        $id =$item['id'];
        $nome =$item['nome'];
        $nome =$item['descricao'];
        $tipo =$item['tipo'];
        $opcoes =$item['opcoes'];
        $pre_definido =$item['pre_definido'];
        $form_id =$item['form_id'];
        $obrigatorio =$item['obrigatorio'];
        $ordem =$item['ordem'];
        
        $html ='<input type="text" name="testy[2]" disabled="true" placeholder="nome" class="form-control"  value="Campo de texto"/>';   
    }
}
