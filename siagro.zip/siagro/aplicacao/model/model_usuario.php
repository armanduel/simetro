<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 */

/**
 * Description of model Usuario
 *
 * @author Armando Manuel
 */

class model_usuario extends bd{
    
    public static function selecionar_usuarios(){
                
        $usuarios = []; 
        $bd=new bd();
        $usuarios = $bd->tabela('usuario')->colher()->paraArray();
        
        return $usuarios;   
       
    }

    public static function criar_usuario($dados) {  // Armando
	    $bd = New bd();
            $usuario = $bd->inserir('usuario',[
                                'nome' => $dados['nome'], 
                                'sobre_nome' => $dados['sobrenome'],                                
                                'telefone' => $dados['telefone'], 
                                'email' => $dados['email'],  
                                'senha' => password_hash($dados['password'], PASSWORD_DEFAULT),
                                'categoria' => $dados['categoria'],
                                'estado' => $dados['estado']
                    ]);

            if ( $usuario ) {
                    $id = $usuario;			
            } else {
                    $id = 0;
            }
        return $id;
        
    }

    public static function editar_usuario($dados) {
			
        if (!isset($dados['id'])){
            return false;
		}				
                $bd = New bd();		
		$usuario = $bd->editar('usuario',
                                [  
                                'nome' => $dados['nome'], 
                                'sobre_nome' => $dados['sobrenome'], 
                                'telefone' => $dados['telefone'], 
                                'email' => $dados['email'],
                                'senha' => password_hash($dados['password'], PASSWORD_DEFAULT),
                                'categoria' => $dados['categoria'],
                                'estado' => $dados['estado']
                                ])->onde('id',$dados['id'])->exec(); 
		//echo $bd->lastId();				
		if ( $usuario ) {
			$id = $usuario;			
		} else {
			$id = 0;
		}
        return $id;		
    }
    
    public static function editar_usuarios( $dados) {  // Armando

        foreach ($dados as $usuario) {

                if($usuario['id']==""){
                    
                    $resultados = self::criar_usuario($usuario);

                 } else {
                     
                    $resultados = self::editar_usuario($usuario);

                 }
           }
            
          return $resultados; 
          
} 
    public static function excluir_usuario( $id) {//Armando

            $bd = New bd();
            $resultados= $bd->excluir('usuario')->onde('id',$id)->exec();		
            return $resultados;
    }
    public static function excluir_usuarios($coluna, $coluna_valor) {

            $bd= new bd();
            $resultados = $bd->excluir('usuario')->onde($coluna, $coluna_valor)->exec();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }      

    public static function selecionar_usuarios_filtro($coluna, $coluna_valor, $ordem='id', $ordem_tipo ='ASC') {

            $bd= new bd();
            $resultados = $bd->tabela('usuario')->onde($coluna, $coluna_valor)->ordenarPor('ordem', 'ASC')->colher();
            $resultados = json_decode(json_encode( $resultados), true);
            //print_r ($resultados);
            return $resultados;
    }


    public static function selecionar_usuario_id( $id ) { // Armando
            $bd= new bd();
            $resultados =$bd->tabela('usuario')->onde($id)->colher()->paraArray();//;
            //$resultados = json_decode(json_encode($resultados), true);
            return $resultados;
    }
    
    public static function selecionar_usuario_email( $email ) { // Armando
        $bd= new bd();
        $resultados =$bd->tabela('usuario')->onde('email', $email)->colher();
        $resultados = json_decode(json_encode($resultados), true);
      
        return $resultados;           
    }  
       
    public static function consulta_sql($consulta){
        $usuarios = []; 
        $bd=new bd();
        $usuarios = $bd->consulta($consulta);
        return $usuarios;
    }
    
    public static function total_usuario(){
        
        $total ="0";
        
        $bd=new bd();
        $total = $bd->contar();
        return $total;
    }
}
