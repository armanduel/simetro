<?php
require_once 'usuario.php';
class inicio extends Controller
{
    //armando tests to load several models
    function __construct()
    {
       // $this->openDatabaseConnection();
       // $this->loadModel("model_usuario");
    }
    public function index(){
        // load views
        //require APP . 'view/_templates/header.php';
//	$id ='1';
//        echo "working";
//        $d = new usuario();
//        $res = $d->selecionar_usuario($id);//$this->model->selecionar_usuario($id);
//        print_r($res['0']);
          session_start();
          $usuario = new usuario();
          $sessao = $usuario->verificar_sessao(); 
          
          if (!empty($sessao)){
              
            require APP . 'view/prod/index.php';
           } else {            
                header('location:' . URL.'usuario/entrar');    
         }          
      echo $sessao;
    }



}
