<?php
require_once APP . 'model/model_usuario.php';
class usuario extends Controller
{   
    function __construct()
    {
        //$this->openDatabaseConnection();
        //$this->loadModel("model_usuario");
    }
    
    public function index()
    {
      
	//self::usuario();
    }

     public static function entrar($message="")
    {   
       $message = $message;
       require APP . 'view/prod/login.php';

    }
    
         public static function sair($message="")
    {      $message = $message;
           session_start();
           session_destroy();
           header('location:' . URL.'usuario/entrar');  
    }
    

         public static function lista()
    {    
          session_start();
          $usuario = new usuario();
          $sessao = $usuario->verificar_sessao(); 
          
          if (!empty($sessao)){              
            $tabela = self::carregar_dados();
            require APP . 'view/prod/usuario.php';
          } else {            
                header('location:' . URL.'usuario/entrar');    
          }
    }
    
    public static function selecionar_usuario($id)
    {   
        $resultados =[];   
        $model= new model_usuario;
        $resultados = $model->selecionar_usuario_id($id);        
        return $resultados;
    }
    
    public static function verificar_sessao(){ 
            
        if(isset($_SESSION['categoria'])){
            return $_SESSION['categoria'];       
        } else {
            return false;
        }     
    }
    public static function verificar_admin(){ 
            
        if(isset($_SESSION['categoria'])){
            
                 if(($_SESSION['categoria'] ==1)){
                    return true; 
                 }
                  
        } else {
            
            return false;
        }     
    }
    
    public static function criar_sessao($email,$pass){
        
        $message ="";
        $resultados =[];   
        $model= new model_usuario;
        $resultados = $model->selecionar_usuario_email($email);
        if(isset($resultados['0'])) 
            {
                $usuario = $resultados['0']; 
                
            }   
        
            if(isset($usuario['id'])) {
                 
                    if((password_verify($pass, $usuario['senha']))){
                            session_start();
                            $_SESSION['categoria'] = $usuario['categoria'];
                            $_SESSION['usuario_id'] = $usuario['id'];
                            $_SESSION['usuario_nome'] = $usuario['nome'];
                            $_SESSION['usuario_sobre_nome'] = $usuario['sobre_nome'];
                  
                      header('location:'.URL); exit();            
                      
                    } else {
                       $message = "<label>a palavra pass nao esta correcta</label>";
                       self::entrar($message);
                       exit();
                    }
            } else {
                $message = "<label> A Sua conta Nao existe, contacte o administrador</label>";
                self::entrar($message);
                exit();
            }     
        return $message;
    }

   protected static function carregar_dados(){
       
       $output = array(); 
       $resultados =[];
       $html = "";
       
       $model= new model_usuario;  
       $resultados = $model->selecionar_usuarios();
       
       $html .=' 
        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Sobre Nome</th>                
                <th>Telefone</th>
                <th>email</th>
                <th>Categoria</th>
                <th>Estado</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <tbody>';
               
        foreach($resultados as $row)
       {
            $estado = '';
            $categoria = '';
               if($row["estado"] == '1'){
                       $estado = '<span class="label label-success">Ativo</span>';
               }
               else{
                       $estado = '<span class="label label-danger">Inativo</span>';
               }
               if($row["categoria"] == '1'){
                       $categoria = '<span class="label label-primary">Administrador</span>';
               }
               else{
                       $categoria = '<span class="label label-default">Usuario</span>';
               }
            $html .='
                <tr>
                    <td>'.$row["nome"].'</td>
                    <td>'.$row["sobre_nome"].'</td>

                    <td>'.$row["telefone"].'</td>
                    <td>'.$row["email"].'</td>
                    <td>'.$categoria.'</td>
                    <td>'.$estado.'</td>
                    <td><button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update">Editar</button>
                    <td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete" data-status="'.$row["estado"].'">Excluir</button></td> 
                </tr>';
        }
        
        $html .='
            </tbody>
            <tfoot>
                <tr>
                    <th>Nome</th>
                    <th>Sobre Nome</th>                
                    <th>Telefone</th>
                    <th>email</th>
                    <th>Categoria</th>
                    <th>Estado</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </tfoot>
        </table>';
        
        return $html;
   }
}

// receber dados via Ajax 

if(isset($_POST["login"])){
   
        $email = $_POST["email"];
        $pass = $_POST["senha"];        
        $dados = new usuario();
        $resultados = $dados->criar_sessao($email, $pass);
        $message = $resultados;
        echo $message;       
}

if(isset($_POST['btn_action'])){
	if($_POST['btn_action'] == 'salvar_usuario'){
            if(isset($_POST["input"])){
		$input = $_POST["input"];

                if(!empty($input)){
                    $usuario = new model_usuario();
                    $resultados = $usuario->criar_usuario($input);

                    if(isset($resultados)){
                            echo 'Novo Usuario Adicionado';
                    }
                }
            }   
	}
        if($_POST['btn_action'] == 'editar_usuario'){
            if(isset($_POST["input"])){
                $input = $_POST["input"];
                $usuario = new model_usuario();
                $resultados = $usuario->editar_usuario($input);
                             
		if(isset($resultados)){
			echo 'Dados do Usuario foram actualizados com Sucesso';
		}
            }  
	}
	if($_POST['btn_action'] == 'selecionar_usuario'){       
            if(isset($_POST["input"])){
                $id = $_POST["input"];
                $usuario = new model_usuario();
                $resultados = $usuario->selecionar_usuario_id($id);                             

		foreach($resultados as $row)
		{
                        $output['id'] = $row['id'];
			$output['nome'] = $row['nome'];
                        $output['sobr_enome'] = $row['sobre_nome'];
			$output['email'] = $row['email'];
                        $output['telefone'] = $row['telefone'];                       
                        $output['categoria'] = $row['categoria'];
                        $output['estado'] = $row['estado'];                        
		}
		echo json_encode($output);
            }
	}

	if($_POST['btn_action'] == 'excluir_usuario'){
           if(isset($_POST["input"])){
                $id = $_POST["input"];  
                $usuario = new model_usuario();
                $resultados = $usuario->excluir_usuario($id);
                if($resultados){
                   echo "Usuario excluido com Sucesso";                    
                }
            }        
        }exit();
}