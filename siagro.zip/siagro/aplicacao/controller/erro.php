<?php

class erro extends Controller
{
     //armano tests to load several models
    function __construct()
    {

    }   
    
    

    public function index()
    {

        require APP . 'view/_templates/cabecalho.php';
        
        echo "pagina para para relatorio de erros ou problemas";
;
    }
}
