<?php
require_once APP . 'model/model_movimento.php';
require_once APP . 'controller/usuario.php';
class movimento extends Controller
{   
    public static function lista()
    {    
          session_start();
          $usuario = new usuario();
          $sessao = $usuario->verificar_sessao(); 
          
          if (!empty($sessao)){              
            $tabela = self::carregar_dados();
            require APP . 'view/prod/movimento.php';
          } else {            
                header('location:' . URL.'usuario/entrar');    
          }
    }
    
    public static function selecionar_movimento($id)
    {   
        $resultados =[];   
        $model= new model_movimento;
        $resultados = $model->selecionar_movimento_id($id);        
        return $resultados;
    }

    protected static function carregar_dados(){
       
       $output = array(); 
       $resultados =[];
       $html = "";
       
       $model= new model_movimento;  
       $resultados = $model->selecionar_movimentos();
       
       $html .=' 
        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Descrição</th>
                <th>Tipo De Movimento</th>                
                <th>Criado</th>
                <th>Criado Por</th>
                <th>Categoria</th>
                <th>estado</th>
                <th>Editar</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <tbody>';
               
        foreach($resultados as $row)
       {
            $estado = '';
            $categoria = '';
               if($row["estado"] == '1'){
                       $estado = '<span class="label label-success">Ativo</span>';
               }
               else{
                       $estado = '<span class="label label-danger">Inativo</span>';
               }
               if($row["categoria"] == '1'){
                       $categoria = '<span class="label label-primary">Entrada</span>';
               }
               else{
                       $categoria = '<span class="label label-default">Saida</span>';
               }
            $html .='
                <tr>
                    <td>'.$row["descricao"].'</td>
                    <td>'.$row["movimento_tipo_id"].'</td>

                    <td>'.$row["criado_em"].'</td>
                    <td>'.$row["criaddo_por"].'</td>
                    <td>'.$categoria.'</td>
                    <td>'.$estado.'</td>
                    <td><button type="button" name="update" id="'.$row["id"].'" class="btn btn-warning btn-xs update">Editar</button>
                    <td><button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete" data-status="'.$row["estado"].'">Excluir</button></td> 
                </tr>';
        }
        
        $html .='
            </tbody>
            <tfoot>
                <tr>
                    <th>Descrição</th>
                    <th>Tipo De Movimento</th>                
                    <th>Categoria</th>
                    <th>estado</th>
                    <th>Criado</th>
                    <th>Criado Por</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </tfoot>
        </table>';
        
        return $html;
   }
}

// receber dados via Ajax 

if(isset($_POST["login"])){
   
        $email = $_POST["email"];
        $pass = $_POST["senha"];        
        $dados = new movimento();
        $resultados = $dados->criar_sessao($email, $pass);
        $message = $resultados;
        echo $message;       
}

if(isset($_POST['btn_action'])){
	if($_POST['btn_action'] == 'salvar_movimento'){
            if(isset($_POST["input"])){
		$input = $_POST["input"];

                if(!empty($input)){
                    $movimento = new model_movimento();
                    $resultados = $movimento->criar_movimento($input);

                    if(isset($resultados)){
                            echo 'Novo Usuario Adicionado';
                    }
                }
            }   
	}
        if($_POST['btn_action'] == 'editar_movimentos'){
            if(isset($_POST["input"])){
                $input = $_POST["input"];
                $movimento = new model_movimentos();
                $resultados = $movimento->editar_movimentos($input);
                             
		if(isset($resultados)){
			echo 'Dados do Usuario foram actualizados com Sucesso';
		}
            }  
	}
	if($_POST['btn_action'] == 'selecionar_movimentos'){       
            if(isset($_POST["input"])){
                $id = $_POST["input"];
                $movimento = new model_movimentos();
                $resultados = $movimento->selecionar_movimentos_id($id);                             

		foreach($resultados as $row)
		{
                        $output['id'] = $row['id'];
			$output['nome'] = $row['nome'];
                        $output['sobr_enome'] = $row['sobre_nome'];
			$output['email'] = $row['email'];
                        $output['telefone'] = $row['telefone'];                       
                        $output['categoria'] = $row['categoria'];
                        $output['estado'] = $row['estado'];                        
		}
		echo json_encode($output);
            }
	}

	if($_POST['btn_action'] == 'excluir_movimentos'){
           if(isset($_POST["input"])){
                $id = $_POST["input"];  
                $movimento = new model_movimentos();
                $resultados = $movimento->excluir_movimentos($id);
                if($resultados){
                   echo "Usuario excluido com Sucesso";                    
                }
            }        
        }exit();
}