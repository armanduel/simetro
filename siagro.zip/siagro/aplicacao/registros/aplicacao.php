<?php

class aplicacao
{
    /** controller */
    private $url_controller = null;

    /** as funcoes da Url*/
    private $url_action = null;

    /** parametros da Url */
    private $url_params = array();

    /**
     * começo da aplicacao
     * Analizao dos dados da Url
     */
    public function __construct()
    {
        // criar um vector de partes da Url
        $this->splitUrl();

         // verificar se o controler existe
        if (!$this->url_controller) {

            require APP . 'controller/inicio.php';
            $page = new inicio();
            $page->index();

        } elseif (file_exists(APP . 'controller/' . $this->url_controller . '.php')) {
           

            // caso o ontroler exista, carregar o ficheiro
         
            require APP . 'controller/' . $this->url_controller . '.php';
            $this->url_controller = new $this->url_controller();

            // verificar se a funcao existe?
            if (method_exists($this->url_controller, $this->url_action)) {

                if (!empty($this->url_params)) {
                    // executar a funcao e passar os parametros
                    call_user_func_array(array($this->url_controller, $this->url_action), $this->url_params);
                } else {
                    // caso nao exista parametros vai executar a acao sem parametros
                    $this->url_controller->{$this->url_action}();
                }

            } else {
                if (strlen($this->url_action) == 0) {
                    // caso nao tenha accao definida vai chama a funcao index do controler
                    $this->url_controller->index();
                }
                else {
                    header('location: ' . URL . 'erro');
                }
            }
        } else {
            header('location: ' . URL . 'erro');
        }
    }

    /**
     * funcao para decodificar a Url
     */
    private function splitUrl()
    {
        if (isset($_GET['url'])) {

            // separar URL
            $url = trim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);

            $this->url_controller = isset($url[0]) ? $url[0] : null;
            $this->url_action = isset($url[1]) ? $url[1] : null;

            // pegar controller e a acao vindos da Url,
            
            unset($url[0], $url[1]);

            // passar a chave para a variavel 
            $this->url_params = array_values($url);


        }
    }
}
