<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Siagro | </title>

    <!-- Bootstrap -->
    <link href="<?php echo URL; ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo URL; ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo URL; ?>vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo URL; ?>vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo URL; ?>build/css/custom.min.css" rel="stylesheet">
    
    

		<script src="<?php echo URL; ?>js/jquery-3.3.1.js"></script>
<!--		<link rel="stylesheet" href="<?php echo URL; ?>css/bootstrap.min.css" />-->
                <link rel="stylesheet" href="<?php echo URL; ?>css/dataTables.min.css" />
		<script src="<?php echo URL; ?>js/jquery.dataTables.min.js"></script>             
		<script src="<?php echo URL; ?>js/dataTables.bootstrap.min.js"></script>		
		<link rel="stylesheet" href="<?php echo URL; ?>css/dataTables.bootstrap.min.css" />
		<script src="<?php echo URL; ?>js/bootstrap.min.js"></script>
                
                <script src="<?php echo URL; ?>js/dataTables.min.js"></script>
                <script src="<?php echo URL; ?>js/jquery-1.10.2.min.js"></script>
    
    
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>SIAGRO</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?php echo URL; ?>/images/img1.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Bem-vindo,</span>
                <h2><?php echo $_SESSION["usuario_nome"].' '.$_SESSION['usuario_sobre_nome']; ?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            
            
            

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Geral</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-home"></i> Inicio <span class="fa fa-chevron-down"></span></a>
                      <ul class="nav child_menu" style="display: block">
                          <li><a href="nova_actividade.php">Nova Actividade</a></li>
                          <li><a href="index2.html">Novo Movimento</a></li>                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-edit"></i> Operações <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                      <li><a href="form_advanced.html">Advanced Components</a></li>
                      <li><a href="form_validation.html">Form Validation</a></li>
                      <li><a href="form_wizards.html">Form Wizard</a></li>
                      <li><a href="form_upload.html">Form Upload</a></li>
                      <li><a href="form_buttons.html">Form Buttons</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-crosshairs"></i> Recursos <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="general_elements.html">General Elements</a></li>
                      <li><a href="media_gallery.html">Media Gallery</a></li>
                      <li><a href="typography.html">Typography</a></li>
                      <li><a href="icons.html">Icons</a></li>
                      <li><a href="glyphicons.html">Glyphicons</a></li>
                      <li><a href="widgets.html">Widgets</a></li>
                      <li><a href="invoice.html">Invoice</a></li>
                      <li><a href="inbox.html">Inbox</a></li>
                      <li><a href="calendar.html">Calendar</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-bar-chart-o"></i> Reatorios <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="chartjs.html">Chart JS</a></li>
                      <li><a href="chartjs2.html">Chart JS2</a></li>
                      <li><a href="morisjs.html">Moris JS</a></li>
                      <li><a href="echarts.html">ECharts</a></li>
                      <li><a href="other_charts.html">Other Charts</a></li>
                    </ul>
                  </li>
                  <li><a href="javascript:void(0)"><i class="fa fa-paw"></i> Agropecuaria <span class="label label-success pull-right">Brevemente</span></a></li>

                </ul>
              </div>
              <div class="menu_section">
                  
                <?php
                    if($_SESSION['categoria'] == '1')
                    {
                ?>
                         
                <h3>Administrador</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-users"></i> Usuarios <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="e_commerce.html">Novo Usuario</a></li>
                      <li><a href="<?php echo URL; ?>usuario/lista">Lista de Usuaros</a></li>
                      <li><a href="project_detail.html">permições</a></li>
                      <li><a href="contacts.html">Cotactos</a></li>              
                    </ul>
                  </li>
                  
                  <li><a><i class="fa fa-cogs"></i> Sistema <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <li><a href="#level1_1">Configuração</a>
                        <li><a>Categorias<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu"><a href="level2.html">Categoria de Equipamentos</a>
                            </li>
                            <li><a href="#level2_1">Categorias de Actividades</a>
                            </li>
                            <li><a href="#level2_2">Tipos de Insumos</a>
                            </li>
                            <li><a href="#level2_2">Tipos de Movimentos</a>
                            </li>
                          </ul>
                        </li>
                        <li><a href="#level1_2">Level One</a>
                        </li>
                    </ul>
                  </li>                  
                  <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Finanças <span class="label label-success pull-right">Brevemente</span></a></li>
                </ul>
                
                <?php
                    }
                ?>
                                  
              </div>

            </div>
            <!-- /sidebar menu -->
            
            
            
            
            
            

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Configuração">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Ecrã Inteiro">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Suspender">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Sair" href="<?php echo URL; ?>usuario/sair">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

          
          
          
          
        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img1.jpg" alt=""><?php echo $_SESSION["usuario_nome"].' '.$_SESSION['usuario_sobre_nome'];?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Perfil do Usuario</a></li>
                    <li><a href="javascript:;">Ajuda</a></li>
                    <li><a href="<?php echo URL; ?>usuario/sair"><i class="fa fa-sign-out pull-right"></i> Sair</a></li>
                  </ul>
                </li>

                <li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-green">6</span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img1.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        
        
        
        
        
        <!-- page content -->
        <div class="right_col" role="main">
		<span id="alert_action"></span>
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
                    <div class="panel-heading">
                    	<div class="row">
                        	<div class="col-lg-10 col-md-10 col-sm-8 col-xs-6">
                            	<h3 class="panel-title">Usuarios</h3>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6" align="right">
                            	<button type="button" name="add" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-success btn-xs">Adicionar</button>
                        	</div>
                        </div>
                       
                        <div class="clear:both"></div>
                   	</div>
                   	<div class="panel-body">
                   		<div class="row"><div class="col-sm-12 table-responsive">
                   			<?php echo $tabela  ?>
                   		</div>
                   	</div>
               	</div>
           	</div>
        </div>
                    
        <div id="userModal" class="modal fade">
        	<div class="modal-dialog">
        		<form method="post" id="form_usuario">
        			<div class="modal-content">
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><i class="fa fa-plus"></i> Adicionar Usuario</h4>
        			</div>
        			<div class="modal-body">
        				<div class="form-group">
                                                <label>Nome </label>
                                                <input type="text" name="usuario_nome" id="usuario_nome" class="form-control" />
                                        </div>
                                        <div class="form-group">
                                                <label>Sobrenome</label>
                                                <input type="text" name="usuario_sobrenome" id="usuario_sobrenome" class="form-control" />
                                        </div>
                                    
                                    
                                        <div class="form-group">
                                                <label>Email</label>
                                                <input type="email" name="usuario_email" id="usuario_email" class="form-control"  />
                                        </div>
                                        <div class="form-group">
                                                <label>Palavra Passe Temporaria</label>
                                                <input type="password" name="usuario_password" id="usuario_password" class="form-control"  />
                                        </div>
                                        
                                        <div class="form-group">
                                                <label>Telefone</label>
                                                <input type="text" name="usuario_telefone" id="usuario_telefone" class="form-control" />
                                        </div>
                                        <div class="form-group">
                                                <label>Numero do Usuario</label>
                                                <input type="text" name="usuario_numero" id="usuario_numero" class="form-control"  />
                                        </div>
                                        
                                        <div class='form-group'>
                                                <input class='form-check-input' name='categoria' type='checkbox' value='1' id='categoria'>
                                                <label class='form-check-label' for='categoria'>Administrador</label>
                                        </div>  
                                        <div class='form-group'>
                                            <input class='form-check-input' name='estado' type='checkbox' value='1' id='estado' checked>
                                                <label class='form-check-label' for='estado'>Activo</label>
                                        </div>  
                                
        			</div>
        			<div class="modal-footer">
                                    <input type="hidden" name="usuario_id" id="usuario_id" value="" />
        				<input type="hidden" name="btn_action" id="btn_action" />
        				<input type="submit" name="action" id="action" class="btn btn-info" value="Adicionar" />
        				<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
        			</div>
        		</div>
        		</form>

        	</div>
        </div>
                    
        </div>
        <!-- /page content -->

       <!-- footer content -->
        <footer>
          <div class="pull-right">
             <a href="index.php">Siagro - O seu Sistema de Confiança</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

<!--     jQuery 
    <script src="<?php echo URL; ?>vendors/jquery/dist/jquery.min.js"></script>
     Bootstrap 
    <script src="<?php echo URL; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>
     FastClick 
    <script src="<?php echo URL; ?>vendors/fastclick/lib/fastclick.js"></script>
     NProgress 
    <script src="<?php echo URL; ?>vendors/nprogress/nprogress.js"></script>
     Chart.js 
    <script src="<?php echo URL; ?>vendors/Chart.js/dist/Chart.min.js"></script>
     jQuery Sparklines 
    <script src="<?php echo URL; ?>vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
     Flot 
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.resize.js"></script>
     Flot plugins 
    <script src="<?php echo URL; ?>vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo URL; ?>vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo URL; ?>vendors/flot.curvedlines/curvedLines.js"></script>
     DateJS 
    <script src="<?php echo URL; ?>vendors/DateJS/build/date.js"></script>
     bootstrap-daterangepicker 
    <script src="<?php echo URL; ?>vendors/moment/min/moment.min.js"></script>
    <script src="<?php echo URL; ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    
     Custom Theme Scripts 
    <script src="<?php echo URL; ?>build/js/custom.min.js"></script>-->-->
    
    <script>
$(document).ready(function(){
    
    $(document).ready(function() {
        $('#tabela_usuario').DataTable();

    } );
    
    $('#tabela_usuario').dataTable( {
    "language": 
            {
                "decimal":        "",
                "emptyTable":     "Nao Ha Dados Disponiveis",
                "info":           "_START_ a _END_ de _TOTAL_ Itens",
                "infoEmpty":      " 0 a 0 de 0 Itens",
                "infoFiltered":   "(Filtrado de um total de _MAX_ Itens)",
                "infoPostFix":    "",
                "thousands":      ".",
                "lengthMenu":     "Mostrar _MENU_ Itens",
                "loadingRecords": "a Processar...",
                "processing":     "a Processar...",
                "search":         "Procurar:",
                "zeroRecords":    "Nada encontrado",
                "paginate": {
                    "first":      "Primeira",
                    "last":       "Ultima",
                    "next":       "Proxima",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": para Ordenar Crescente",
                    "sortDescending": ": Para Ordenar Decrescente"
                }
            }

   } );    

    $('#add_button').click(function(){
            $('#form_usuario')[0].reset();
            $('.modal-title').html("<i class='fa fa-plus'></i> Adicionar Usuario");
            $('#action').val("salvar");
            $('#btn_action').val("salvar_usuario");
    });


    $(document).on('submit', '#form_usuario', function(event){
        event.preventDefault();
        var btn_action = $('#btn_action').val(); 
        //$('#action').attr('disabled', 'disabled');
        var form_data = $(this).serializeArray();
    
        var input=[];     
        
        var id = $('#usuario_id').val();
        var nome = $('#usuario_nome').val();
        var sobrenome = $('#usuario_sobrenome').val();
        var telefone = $('#usuario_telefone').val();
        var numero = $('#usuario_numero').val();
        var password = $('#usuario_password').val();
        var email = $('#usuario_email').val();         
        var categoria = "";if (document.getElementById("categoria").checked == true){categoria= "1";} else {categoria = "";}
        var estado = "";if (document.getElementById("estado").checked == true){estado= "1";} else {estado = "";} 
        
        var input = {id:id, nome:nome, sobrenome:sobrenome, telefone:telefone, numero:numero, password:password, categoria:categoria, estado:estado, email:email};  
       
        console.log(input);
        $.ajax({
            url:"usuario",
            method:"POST",
             //data:form_data,
           data:{input:input, btn_action:btn_action},
           success:function(data){                
                console.log(data);
                $('#form_usuario')[0].reset();
                $('#userModal').modal('hide');
                $('#action').attr('disabled', false);                
                $('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
                $('#alert_action').fadeOut(3000);    
                setTimeout(location.reload.bind(location), 6000);
           }
        })
    });

    $(document).on('click', '.update', function(){
            var usuario_id = $(this).attr("id");
            var btn_action = 'selecionar_usuario';

            $.ajax({
                    url:"usuario",
                    method:"POST",
                    data:{input:usuario_id, btn_action:btn_action},
                    
                    dataType:"json",
                    success:function(data)
                    { console.log(data);
                        
                            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Editar Usuario");
                            $('#userModal').modal('show');
                            $('#usuario_nome').val(data["nome"]);
                            $('#usuario_sobre_nome').val(data.sobrenome);
                            $('#usuario_email').val(data.email);
                            $('#usuario_telefone').val(data.telefone);
                            //$('#usuario_numero').val(data.numero);

                            if (data.categoria == '1'){check("categoria");}else{uncheck("categoria");}
                            if (data.estado == '1'){check("estado");}else{uncheck("estado");}
                           
                            $('#usuario_id').val(usuario_id);
                            $('#action').val('editar');
                            $('#btn_action').val('editar_usuario');
                            $('#usuario_password').attr('required', false); 
                            
                            function check(id) {
                                 document.getElementById(id).checked = true;
                             }

                             function uncheck(id) {
                                 document.getElementById(id).checked = false;
                             }

                                
                    }
            })
    });


    $(document).on('click', '.delete', function(){
            var usuario_id = $(this).attr("id");
            var status = $(this).data('status');
            var btn_action = "excluir_usuario";
            if(confirm("Tem Certeza que deseja Excluir este Usuario?"))
            {
                    $.ajax({
                            url:"usuario",
                            method:"POST",
                            data:{input:usuario_id, btn_action:btn_action},
                            success:function(data)
                            {
                                    $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
                                    $('#alert_action').fadeOut(3000);
                                    setTimeout(location.reload.bind(location), 4000);
                            }
                    })
            }
            else
            {
                    return false;
            }
    });

});
</script>
  </body>
</html>
