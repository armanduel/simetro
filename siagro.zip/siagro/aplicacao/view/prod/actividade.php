<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>DataTables | Gentelella</title>

    <!-- Bootstrap -->
    <link href="<?php echo URL; ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo URL; ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo URL; ?>vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo URL; ?>vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="<?php echo URL; ?>vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo URL; ?>vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo URL; ?>vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo URL; ?>vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo URL; ?>vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
    
    
    
    
        <!-- jQuery -->
    <script src="<?php echo URL; ?>vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo URL; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo URL; ?>vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo URL; ?>vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="<?php echo URL; ?>vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="<?php echo URL; ?>vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo URL; ?>vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo URL; ?>vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo URL; ?>vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo URL; ?>vendors/pdfmake/build/vfs_fonts.js"></script>

        <script>
$(document).ready(function(){
    
    $(document).ready(function() {
        $('#datatable-responsive').DataTable();

    } );
    
    $('#datatable-responsive').dataTable( {
    "language": 
            {
                "decimal":        "",
                "emptyTable":     "Nao Ha Dados Disponiveis",
                "info":           "_START_ a _END_ de _TOTAL_ Itens",
                "infoEmpty":      " 0 a 0 de 0 Itens",
                "infoFiltered":   "(Filtrado de um total de _MAX_ Itens)",
                "infoPostFix":    "",
                "thousands":      ".",
                "lengthMenu":     "Mostrar _MENU_ Linhas",
                "loadingRecords": "a Processar...",
                "processing":     "a Processar...",
                "search":         "Procurar:",
                "zeroRecords":    "Nada encontrado",
                "paginate": {
                    "first":      "Primeira",
                    "last":       "Ultima",
                    "next":       "Proxima",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": para Ordenar Crescente",
                    "sortDescending": ": Para Ordenar Decrescente"
                }
            }

   } );    

    $('#add_button').click(function(){
            $('#form_usuario')[0].reset();
            $('.modal-title').html("<i class='fa fa-plus'></i> Adicionar Movimento");
            $('#action').val("salvar");
            $('#btn_action').val("salvar_movimento");
    });


    $(document).on('submit', '#form_usuario', function(event){
        event.preventDefault();
        var btn_action = $('#btn_action').val(); 
        //$('#action').attr('disabled', 'disabled');
        var form_data = $(this).serializeArray();
    
        var input=[];     
        
        var id = $('#usuario_id').val();
        var nome = $('#usuario_nome').val();
        var sobrenome = $('#usuario_sobrenome').val();
        var telefone = $('#usuario_telefone').val();
        var numero = $('#usuario_numero').val();
        var password = $('#usuario_password').val();
        var email = $('#usuario_email').val();         
        var categoria = "";if (document.getElementById("categoria").checked == true){categoria= "1";} else {categoria = "";}
        var estado = "";if (document.getElementById("estado").checked == true){estado= "1";} else {estado = "";} 
        
        var input = {id:id, nome:nome, sobrenome:sobrenome, telefone:telefone, numero:numero, password:password, categoria:categoria, estado:estado, email:email};  
       
        console.log(input);
        $.ajax({
            url:"usuario",
            method:"POST",
             //data:form_data,
           data:{input:input, btn_action:btn_action},
           success:function(data){                
                console.log(data);
                $('#form_usuario')[0].reset();
                $('#userModal').modal('hide');
                $('#action').attr('disabled', false);                
                $('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
                $('#alert_action').fadeOut(3000);    
                setTimeout(location.reload.bind(location), 6000);
           }
        })
    });

    $(document).on('click', '.update', function(){
            var usuario_id = $(this).attr("id");
            var btn_action = 'selecionar_usuario';

            $.ajax({
                    url:"usuario",
                    method:"POST",
                    data:{input:usuario_id, btn_action:btn_action},
                    
                    dataType:"json",
                    success:function(data)
                    { console.log(data);
                        
                            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Editar Usuario");
                            $('#userModal').modal('show');
                            $('#usuario_nome').val(data["nome"]);
                            $('#usuario_sobre_nome').val(data.sobrenome);
                            $('#usuario_email').val(data.email);
                            $('#usuario_telefone').val(data.telefone);
                            //$('#usuario_numero').val(data.numero);

                            if (data.categoria == '1'){check("categoria");}else{uncheck("categoria");}
                            if (data.estado == '1'){check("estado");}else{uncheck("estado");}
                           
                            $('#usuario_id').val(usuario_id);
                            $('#action').val('editar');
                            $('#btn_action').val('editar_usuario');
                            $('#usuario_password').attr('required', false); 
                            
                            function check(id) {
                                 document.getElementById(id).checked = true;
                             }

                             function uncheck(id) {
                                 document.getElementById(id).checked = false;
                             }

                                
                    }
            })
    });


    $(document).on('click', '.delete', function(){
            var usuario_id = $(this).attr("id");
            var status = $(this).data('status');
            var btn_action = "excluir_usuario";
            if(confirm("Tem Certeza que deseja Excluir este Usuario?"))
            {
                    $.ajax({
                            url:"usuario",
                            method:"POST",
                            data:{input:usuario_id, btn_action:btn_action},
                            success:function(data)
                            {
                                    $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
                                    $('#alert_action').fadeOut(3000);
                                    setTimeout(location.reload.bind(location), 4000);
                            }
                    })
            }
            else
            {
                    return false;
            }
    });

});
</script>

    <!-- Custom Theme Style -->
    <link href="<?php echo URL; ?>build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          
<?php include APP . 'view/templates/header.php'; ?>
          
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Usuarios <small></small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">

                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Lista de Usuarios<small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><button type="button" name="add" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-success btn-xs">Novo Usuario</button>
                          <a style="text-align: center" class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
<!--                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a></li>-->
                      
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<!--                    <p class="text-muted font-13 m-b-30">
                        Lista de Todos Usuarios Cadatrados no Sistema
                    </p>
                      
                    --><?php echo $tabela  ?>
                    
                  </div>
                </div>
              </div>


            </div>
          </div>
        
            
            <div id="userModal" class="modal fade">
        	<div class="modal-dialog">
        		<form method="post" id="form_usuario">
        			<div class="modal-content">
        			<div class="modal-header">
        				<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><i class="fa fa-plus"></i> Adicionar Usuario</h4>
        			</div>
        			<div class="modal-body">
        				<div class="form-group">
                                                <label>Nome </label>
                                                <input type="text" name="usuario_nome" id="usuario_nome" class="form-control" />
                                        </div>
                                        <div class="form-group">
                                                <label>Sobrenome</label>
                                                <input type="text" name="usuario_sobrenome" id="usuario_sobrenome" class="form-control" />
                                        </div>
                                    
                                    
                                        <div class="form-group">
                                                <label>Email</label>
                                                <input type="email" name="usuario_email" id="usuario_email" class="form-control"  />
                                        </div>
                                        <div class="form-group">
                                                <label>Palavra Passe Temporaria</label>
                                                <input type="password" name="usuario_password" id="usuario_password" class="form-control"  />
                                        </div>
                                        
                                        <div class="form-group">
                                                <label>Telefone</label>
                                                <input type="text" name="usuario_telefone" id="usuario_telefone" class="form-control" />
                                        </div>
                                        <div class="form-group">
                                                <label>Numero do Usuario</label>
                                                <input type="text" name="usuario_numero" id="usuario_numero" class="form-control"  />
                                        </div>
                                        
                                        <div class='form-group'>
                                                <input class='form-check-input' name='categoria' type='checkbox' value='1' id='categoria'>
                                                <label class='form-check-label' for='categoria'>Administrador</label>
                                        </div>  
                                        <div class='form-group'>
                                            <input class='form-check-input' name='estado' type='checkbox' value='1' id='estado' checked>
                                                <label class='form-check-label' for='estado'>Activo</label>
                                        </div>  
                                
        			</div>
        			<div class="modal-footer">
                                    <input type="hidden" name="usuario_id" id="usuario_id" value="" />
        				<input type="hidden" name="btn_action" id="btn_action" />
        				<input type="submit" name="action" id="action" class="btn btn-info" value="Adicionar" />
        				<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
        			</div>
        		</div>
        		</form>

        	</div>
        </div>
        
        
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>


    <!-- Custom Theme Scripts -->
    <script src="<?php echo URL; ?>build/js/custom.min.js"></script>

  </body>
</html><?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

