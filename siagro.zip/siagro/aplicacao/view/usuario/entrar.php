<!DOCTYPE html>
<html>
	<head>
		<title>Simetro</title>		
		<script src="<?php echo URL; ?>js/jquery-1.10.2.min.js"></script>
		<link rel="stylesheet" href="<?php echo URL; ?>css/bootstrap.min.css" />
		<script src="<?php echo URL; ?>js/bootstrap.min.js"></script>
	</head>
	<body>
		<br />
		<div class="container">
			<h2 align="center">Simetro</h2>
			<br />
			<div class="panel panel-default">
				<div class="panel-heading">Entrar</div>
				<div class="panel-body">
					<form action="" method="post">
						<?php echo $message; ?>
						<div class="form-group">
							<label>Email do Usuario</label>
							<input type="text" name="user_email" class="form-control" required />
						</div>
						<div class="form-group">
							<label>Senha</label>
							<input type="password" name="user_password" class="form-control" required />
						</div>
						<div class="form-group">
							<input type="submit" name="login" value="Login" class="btn btn-info" />
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>