<?php
//require_once 'up';
?>
<html>
 <head>
<!--  <title>Simetro</title>
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>-->
  <style>
   body
   {
    margin:0;
    padding:0;
    background-color:#f1f1f1;
   }
   .box
   {
    width:800px;
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:5px;
    margin:10px;
   }
   #page_list li
   {
    padding:16px;
    background-color:#f9f9f9;
    border:1px dotted #ccc;
    cursor:move;
    margin-top:12px;
   }
   #page_list li.ui-state-highlight
   {
    padding:24px;
    background-color:#ffffcc;
    border:1px dotted #ccc;
    cursor:move;
    margin-top:12px;
   }
  </style>

 </head>
 <body>
  <div class="container box col-sm-7">
      <div class="col-sm-12">
                <h1 align="center">Formulario</h1>
                <br />
                <ul class="list-unstyled" id="page_list">
                    
                    <?php 
                    echo $dados;
                    ?>      
                </ul>
                <div align="center">
                   <button type="button" name="save" id="save" class="btn btn-info" >Guardar</button>
                </div> 
            <input type="hidden" name="page_order_list" id="page_order_list" />
      </div> 
         
    </div>  
     
    
     
     
     <div class="container box col-sm-4">
         
   
          <div>
              
                <div id="row1" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Campo de texto</label>
                    </div>    
                    <div class="col-sm-6">
                        <input type="text" name="testy[2]" disabled="true" placeholder="campo de texto" class="form-control"  value=""/>
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="text" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>     
                  
                <div id="row1" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Area de Texto</label>
                    </div>    
                    <div class="col-sm-6">
                        <textarea name='' placeholder='Area de texto' class='form-control' disabled="true"></textarea>
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="text_area" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>  
              
              
              
              
               <div id="row1" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Radio Btn</label>
                    </div>    
                    <div class="col-sm-6">
                        
                        
                        <div class='form-check'>
                            <input class='form-check-input' name='group20' type='radio' id='radio120' disabled="true" checked='checked'>
                            <label class='form-check-label' for='radio120'>Opcao 1</label>
                        </div>
                        <div class='form-check'>
                            <input class='form-check-input' name='group20' type='radio' disabled="true" id='radio121'>
                            <label class='form-check-label' for='radio121'>opcao 2</label>
                        </div>
                        <div class='form-check'>
                            <input class='form-check-input' name='group20' type='radio' disabled="true" id='radio122'>
                            <label class='form-check-label' for='radio122'>opcao 3</label>
                        </div>                    
                        
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="radio" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>  
              
              
              
              
              
             <div id="row1" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">checkbox</label>
                    </div>    
                    <div class="col-sm-6">
                        
                        
                        <div class='form-check'>
                            <input class='form-check-input' name='group20' type='checkbox' disabled="true" id='checkbox0'checked='checked'>
                            <label class='form-check-label' for='checkbox0'>Opcao 1</label>
                        </div>
                        <div class='form-check'>
                            <input class='form-check-input' name='group21' type='checkbox' disabled="true" id='checkbox1'>
                            <label class='form-check-label' for='checkbox1'>opcao 2</label>
                        </div>
                        <div class='form-check'>
                            <input class='form-check-input' name='group22' type='checkbox' disabled="true" id='checkbox2'>
                            <label class='form-check-label' for='checkbox2'>opcao 3</label>
                        </div>                    
                        
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="checkbox" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>               
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
                <div id="row3" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Campo de seleccao</label>
                    </div>    
                    <div class="col-sm-6">
                        <select name='testy[16][]' disabled="true" class='form-control'>
			<option value='opcao1'>opcao1</option><option value='opcao2'>opcao2</option><option value='opcao3'>opcao3</option>
                        </select>
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="select" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>  
                
                <div id="row3" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Seleccao Multipla</label>
                    </div>    
                    <div class="col-sm-6">
                        <select name='testy[16][]' disabled="true" class='form-control' multiple  style='height:50px;'>
			<option value='opcao1'>opcao1</option><option value='opcao2'>opcao2</option><option value='opcao3'>opcao3</option>
                        </select>
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="multi_select" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>  
              
              
              
                <div id="row2" class="row"> 
                    <div class="form-group row col-sm-5">
                        <label for="colFormLabelSm" class="col-form-label col-form-label-sm" align="right">Campo de ficheiro</label>
                    </div>    
                    <div class="col-sm-6">
                        <input type='file' disabled='true' name='testy' class='form-control' id='user_image' placeholder='file'/>
                    </div>
                    <div class="col-sm-1" align="right">
                        <button type='button' name='save' id="file" data-row='row1' class='btn btn-success btn-xs add'>+</button>
                    </div>
                </div>   
                  
              
                
             
          </div>
          
    </div>
    
     

     
        <div id="itemModal" class="modal fade">
            <div class="modal-dialog">
                <form method="post" id="item_form">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title"><i class="fa fa-plus"></i> Add Product</h4>
                        </div>
                        <div class="modal-body">
                            
                            <div class="form-group">
                                <label>Numero:</label>
                                <input type="text" name="item_id" id="item_id" class="form-control" required />
                            </div>
                            <div class="form-group">
                                <label>Nome do Campo</label>
                                <input type="text" name="item_nome" id="item_nome" class="form-control" required />
                            </div>
                            <div class="form-group">
                                <label>Descricao</label>
                                <textarea name="item_descricao" id="item_descricao" class="form-control" rows="5"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Opcoes</label>
                                <textarea name="item_opcoes" id="item_opcoes" class="form-control" rows="5"></textarea>
                            </div>
                            <div class="form-group">
                                <label> Valor Pre-definido</label>
                                <input type="text" name="item_pre_definido" id="item_pre_definido" class="form-control" required />
                            </div>
                            
                            <div class="form-group">
                                <label for='obrigatorio'>Obrigatorio?</label>                                
                                <input class='form-control' type="checkbox" name="item_obrigatorio" checked value="1" id="obrigatorio">
                            </div>
                            
                        </div>          
                        <div class="modal-footer">
                            <input type="hidden" name="product_id" id="product_id" />
                            <input type="hidden" name="btn_action" id="btn_action" />
                            <input type="submit" name="action" id="action" class="btn btn-info" value="Salvar" />
                            <button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>    
     

 </body>
</html>

<script>
$(document).ready(function(){
    
    
    
   $('#text').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";
        html_code += "<input type='text' name='testy[2]' placeholder='escreva o nome do campo' field_type='text' id='' class='form-control novo' align='right' value=''/>";
        html_code +="</div><div class='col-sm-6'><input type='text' name='testy[2]' disabled='true' placeholder='nome' class='form-control'  value='Campo de texto'/></div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button>";        
        html_code +="<button type='button' margin_left='5px'name='save' id='67' data-row='row1' class='btn btn-success btn-xs editar'>*</button></div></li>";
        $("#page_list").append(html_code);
   });  
         $('#text_area').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='text_area' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'>";
        html_code +="<textarea name='' placeholder='Area de texto' class='form-control' disabled='true'></textarea>";
        html_code +="</div>";
        //html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        html_code += "<span class='input-group-addon'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button>";
        html_code += "<button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></span>";
        $("#page_list").append(html_code);
   });
 
   
      $('#file').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='file' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'>";
        html_code +="<input type='file' disabled='true' name='testy' class='form-control' id='user_image' placeholder='ficheiro'/>";
        html_code +="</div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        $("#page_list").append(html_code);
        
   });
   
   
         $('#radio').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='radio' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'>";
        html_code +=" <div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='radio' id='radio120' disabled='true' checked='checked'>";
        html_code +="<label class='form-check-label' for='radio120'>Opcao 1</label>";
        html_code +="</div>";
        html_code +="<div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='radio' disabled='true' id='radio121'>";
        html_code +="<label class='form-check-label' for='radio121'>opcao 2</label>";
        html_code +="</div>";
        html_code +="<div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='radio' disabled='true' id='radio122'>";
        html_code +="<label class='form-check-label' for='radio122'>opcao 3</label>";
        html_code +="</div> ";
        html_code +="</div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        $("#page_list").append(html_code);
        
   });


         $('#checkbox').click(function(){       
        var html_code="<li class='form-group row' c_type='checkbox'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='checkbox' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'>";
        html_code +=" <div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='checkbox' id='checkbox0' disabled='true' checked='checked'>";
        html_code +="<label class='form-check-label' for='checkbox0'>Opcao 1</label>";
        html_code +="</div>";
        html_code +="<div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='checkbox' disabled='true' id='checkbox1'>";
        html_code +="<label class='form-check-label' for='checkbox1'>opcao 2</label>";
        html_code +="</div>";
        html_code +="<div class='form-check'>";
        html_code +="<input class='form-check-input' name='group20' type='checkbox' disabled='true' id='checkbox2'>";
        html_code +="<label class='form-check-label' for='checkbox2'>opcao 3</label>";
        html_code +="</div> ";
        html_code +="</div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        $("#page_list").append(html_code);
        
   });
   
 
       $('#select').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='select' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'><select name='testy[16][]' disabled='true' class='form-control'><option value='opcao1'>opcao1</option><option value='opcao2'>opcao2</        option><option value='opcao3'>opcao3</option></select></div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        $("#page_list").append(html_code);
   });
 
        $('#multi_select').click(function(){       
        var html_code="<li class='form-group row' c_type='text'>";							
        html_code +="<div class='col-sm-5 '>";        
        html_code += "<input type='text' name='' placeholder='escreva o nome do campo' field_type='select' id='' class='form-control novo' align='right' value=''/>";        
        html_code +="</div>";
        html_code +="<div class='col-sm-6'><select name='testy[16][]' disabled='true' class='form-control' multiple  style='height:50px;'><option value='opcao1'>opcao1</option><option            value='opcao2'>opcao2</option><option value='opcao3'>opcao3</option></select></div>";
        html_code +="<div class='col-sm-1'><button type='button' name='remove' data-row='row' class='btn btn-danger btn-xs remove' id='34'>-</button></div></li>";
        $("#page_list").append(html_code);
   });
 
 
    
   $('#save').click(function(){   
       var input=[];
       var btn_action = 'salvar';
       
       $('.novo').each(function (index, value) {
          var id = $(this).attr('id');
          var field_type = $(this).attr('field_type');
          var label = $(this).val();

        var item = {id:id, tipo:field_type, nome:label, ordem:index};
        input.push(item);        

        });
        
       // console.log(input);        

            $.ajax({
                url:"application/controller/FormItens.php",
                method:"POST",
                data:{input:input, btn_action:btn_action},
                success:function(data)
                {
                alert(data);
                }
            });

    });
 
            
    $(document).on('click', '.remove', function(){
        var id = $(this).attr('id');
        var btn_action = 'apagar';

        $.ajax({
            url:"update.php",
            method:"POST",
            data:{input:id, btn_action:btn_action},
            success:function(data)
            {
            alert(data);
            }
        });
        $($(this).parents('li')).remove();
    });
            
    $(document).on('click', '.editar', function(){
        var id = $(this).attr("id");
        var btn_action = 'selecionar_um';
        alert(id);
        $.ajax({
            url:"update.php",
            method:"POST",
            data:{input:id, btn_action:btn_action},
            dataType:"json",
            success:function(data){
                $('#itemModal').modal('show');
                $('#item_id').val(data.id);
                $('#brand_id').html(data.brand_select_box);
                $('#item_nome').val(data.nome);
                $('#item_descricao').val(data.descricao);
                $('#item_opcoes').val(data.opcoes);
                $('#item_pre_definido').val(data.pre_definido);
                $('#item_obrigatorio').val(data.obrigatorio);               
                $('#action').val("salvar");
                $('#btn_action').val("salvar");
            }
        });
    });    
    
    
    
    $(document).on('submit', '#item_form', function(event){
        event.preventDefault();
        $('#action').attr('disabled', 'disabled');
        var form_data = $(this).serializeArray();
        var btn_action = "salvar_dados";          
          
        var input=[];     
        
        var id = $('#item_id').val();
        var nome = $('#item_nome').val();
        var descricao = $('#item_descricao').val();
        var opcoes = $('#item_opcoes').val();
        var pre_definido = $('#item_pre_definido').val();
        var obrigatorio = "";if (document.getElementById("obrigatorio").checked == true){obrigatorio= "1";} else {obrigatorio = "";}        
        var input = {id:id, nome:nome, descricao:descricao, obrigatorio:obrigatorio, opcoes:opcoes, pre_definido:pre_definido};  
        
        console.log(input);
        $.ajax({
            url:"update.php",
            method:"POST",
             //data:form_data,
           data:{input:input, btn_action:btn_action},
           success:function(data){                
                console.log(data);
                $('#item_form')[0].reset();
                $('#itemModal').modal('hide');
               //$('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
                $('#action').attr('disabled', false);
                //productdataTable.ajax.reload();
           }
        })
    });
            

   $(function() {
         $( "#datepicker" ).datepicker();
    }); 
    
   $( "#page_list" ).sortable({
        placeholder : "ui-state-highlight",
        update  : function(event, ui){            
            var page_id_array = new Array();
            $('#page_list li').each(function(){
                page_id_array.push($(this).attr("id"));
            });
        }
    });

});
</script>
