       <!-- footer content -->
        <footer>
          <div class="pull-right">
             <a href="index.php">Siagro - O seu Sistema de Confiança</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo URL; ?>vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo URL; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo URL; ?>vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo URL; ?>vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo URL; ?>vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- jQuery Sparklines -->
    <script src="<?php echo URL; ?>vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
    <!-- Flot -->
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo URL; ?>vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo URL; ?>vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo URL; ?>vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo URL; ?>vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="<?php echo URL; ?>vendors/DateJS/build/date.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo URL; ?>vendors/moment/min/moment.min.js"></script>
    <script src="<?php echo URL; ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="<?php echo URL; ?>build/js/custom.min.js"></script>-->
    
    <script>
$(document).ready(function(){
    
    $(document).ready(function() {
        $('#tabela_usuario').DataTable();

    } );
    
    $('#tabela_usuario').dataTable( {
    "language": 
            {
                "decimal":        "",
                "emptyTable":     "Nao Ha Dados Disponiveis",
                "info":           "_START_ a _END_ de _TOTAL_ Itens",
                "infoEmpty":      " 0 a 0 de 0 Itens",
                "infoFiltered":   "(Filtrado de um total de _MAX_ Itens)",
                "infoPostFix":    "",
                "thousands":      ".",
                "lengthMenu":     "Mostrar _MENU_ Itens",
                "loadingRecords": "a Processar...",
                "processing":     "a Processar...",
                "search":         "Procurar:",
                "zeroRecords":    "Nada encontrado",
                "paginate": {
                    "first":      "Primeira",
                    "last":       "Ultima",
                    "next":       "Proxima",
                    "previous":   "Anterior"
                },
                "aria": {
                    "sortAscending":  ": para Ordenar Crescente",
                    "sortDescending": ": Para Ordenar Decrescente"
                }
            }

   } );    

    $('#add_button').click(function(){
            $('#form_usuario')[0].reset();
            $('.modal-title').html("<i class='fa fa-plus'></i> Adicionar Usuario");
            $('#action').val("salvar");
            $('#btn_action').val("salvar_usuario");
    });


    $(document).on('submit', '#form_usuario', function(event){
        event.preventDefault();
        var btn_action = $('#btn_action').val(); 
        //$('#action').attr('disabled', 'disabled');
        var form_data = $(this).serializeArray();
    
        var input=[];     
        
        var id = $('#usuario_id').val();
        var nome = $('#usuario_nome').val();
        var sobrenome = $('#usuario_sobrenome').val();
        var telefone = $('#usuario_telefone').val();
        var numero = $('#usuario_numero').val();
        var password = $('#usuario_password').val();
        var email = $('#usuario_email').val();         
        var categoria = "";if (document.getElementById("categoria").checked == true){categoria= "1";} else {categoria = "";}
        var estado = "";if (document.getElementById("estado").checked == true){estado= "1";} else {estado = "";} 
        
        var input = {id:id, nome:nome, sobrenome:sobrenome, telefone:telefone, numero:numero, password:password, categoria:categoria, estado:estado, email:email};  
       
        console.log(input);
        $.ajax({
            url:"usuario",
            method:"POST",
             //data:form_data,
           data:{input:input, btn_action:btn_action},
           success:function(data){                
                console.log(data);
                $('#form_usuario')[0].reset();
                $('#userModal').modal('hide');
                $('#action').attr('disabled', false);                
                $('#alert_action').fadeIn().html('<div class="alert alert-success">'+data+'</div>');
                $('#alert_action').fadeOut(3000);    
                setTimeout(location.reload.bind(location), 6000);
           }
        })
    });

    $(document).on('click', '.update', function(){
            var usuario_id = $(this).attr("id");
            var btn_action = 'selecionar_usuario';

            $.ajax({
                    url:"usuario",
                    method:"POST",
                    data:{input:usuario_id, btn_action:btn_action},
                    
                    dataType:"json",
                    success:function(data)
                    { console.log(data);
                        
                            $('.modal-title').html("<i class='fa fa-pencil-square-o'></i> Editar Usuario");
                            $('#userModal').modal('show');
                            $('#usuario_nome').val(data["nome"]);
                            $('#usuario_sobre_nome').val(data.sobrenome);
                            $('#usuario_email').val(data.email);
                            $('#usuario_telefone').val(data.telefone);
                            //$('#usuario_numero').val(data.numero);

                            if (data.categoria == '1'){check("categoria");}else{uncheck("categoria");}
                            if (data.estado == '1'){check("estado");}else{uncheck("estado");}
                           
                            $('#usuario_id').val(usuario_id);
                            $('#action').val('editar');
                            $('#btn_action').val('editar_usuario');
                            $('#usuario_password').attr('required', false); 
                            
                            function check(id) {
                                 document.getElementById(id).checked = true;
                             }

                             function uncheck(id) {
                                 document.getElementById(id).checked = false;
                             }

                                
                    }
            })
    });


    $(document).on('click', '.delete', function(){
            var usuario_id = $(this).attr("id");
            var status = $(this).data('status');
            var btn_action = "excluir_usuario";
            if(confirm("Tem Certeza que deseja Excluir este Usuario?"))
            {
                    $.ajax({
                            url:"usuario",
                            method:"POST",
                            data:{input:usuario_id, btn_action:btn_action},
                            success:function(data)
                            {
                                    $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
                                    $('#alert_action').fadeOut(3000);
                                    setTimeout(location.reload.bind(location), 4000);
                            }
                    })
            }
            else
            {
                    return false;
            }
    });

});
</script>
  </body>
</html>