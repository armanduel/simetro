<?php
//require_once 'up';
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Simetro</title>
		<script src="<?php echo URL; ?>js/jquery-3.3.1.js"></script>
		<link rel="stylesheet" href="<?php echo URL; ?>css/bootstrap.min.css" />
                <link rel="stylesheet" href="<?php echo URL; ?>css/dataTables.min.css" />
		<script src="<?php echo URL; ?>js/jquery.dataTables.min.js"></script>             
		<script src="<?php echo URL; ?>js/dataTables.bootstrap.min.js"></script>		
		<link rel="stylesheet" href="<?php echo URL; ?>css/dataTables.bootstrap.min.css" />
		<script src="<?php echo URL; ?>js/bootstrap.min.js"></script>
                
                <script src="<?php echo URL; ?>js/dataTables.min.js"></script>
<!--                <script src="<?php echo URL; ?>js/jquery-1.10.2.min.js"></script>-->
	</head>
	<body>
		<br />
		<div class="container">
			<h2 align="center">Simetro</h2>

			<nav class="navbar navbar-inverse">
				<div class="container-fluid">
					<div class="navbar-header">
                                            <ul class="nav navbar-nav">
                                            <li><a href="<?php echo URL; ?>" class="navbar-brand">Inicio</a></li>
                                            </ul>
					</div>
					<ul class="nav navbar-nav">
					<?php
//					if($_SESSION['categoria'] == '1')
//					{
					?>
						<li><a href="<?php echo URL; ?>usuario">Usuario</a></li>
						<li><a href="nada">Formulario</a></li>
						<li><a href="nada">Requerimentos</a></li>						
					<?php
//					}
					?>
						<li><a href="nada">Actividades</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count"></span> <?php echo "Armando Manuel";//echo $_SESSION["user_name"]; ?></a>
							<ul class="dropdown-menu">
								<li><a href="profile">Perfil do Usuario</a></li>
								<li><a href="logout.php">Sair</a></li>
							</ul>
						</li>
					</ul>

				</div>
			</nav>

                        
               <?phpAPP?'view/_templates'>