-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 30-Maio-2018 às 22:57
-- Versão do servidor: 10.1.28-MariaDB
-- PHP Version: 7.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simetro`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `actividades`
--

CREATE TABLE `actividades` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_registo` date NOT NULL,
  `actividade_tipo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `formulario`
--

CREATE TABLE `formulario` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` varchar(250) DEFAULT NULL,
  `campos` varchar(600) DEFAULT NULL,
  `data_registo` date NOT NULL,
  `actualizado_por` int(11) DEFAULT NULL,
  `estado` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `form_itens`
--

CREATE TABLE `form_itens` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `descricao` varchar(250) DEFAULT NULL,
  `tipo` varchar(11) DEFAULT NULL,
  `opcoes` varchar(250) DEFAULT NULL,
  `pre_definido` varchar(250) DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  `obrigatorio` tinyint(1) DEFAULT NULL,
  `ordem` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `form_itens`
--

INSERT INTO `form_itens` (`id`, `nome`, `descricao`, `tipo`, `opcoes`, `pre_definido`, `form_id`, `obrigatorio`, `ordem`) VALUES
(53, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(110, '', NULL, 'text_area', NULL, NULL, 1, NULL, 1),
(180, '', NULL, '', NULL, NULL, 1, NULL, 0),
(181, '', NULL, '', NULL, NULL, 1, NULL, 0),
(182, '', NULL, '', NULL, NULL, 1, NULL, 0),
(183, '', NULL, '', NULL, NULL, 1, NULL, 0),
(184, '', NULL, '', NULL, NULL, 1, NULL, 0),
(185, '', NULL, '', NULL, NULL, 1, NULL, 0),
(186, '', NULL, '', NULL, NULL, 1, NULL, 0),
(187, '', NULL, '', NULL, NULL, 1, NULL, 0),
(188, '', NULL, '', NULL, NULL, 1, NULL, 0),
(189, '', NULL, '', NULL, NULL, 1, NULL, 0),
(190, '', NULL, '', NULL, NULL, 1, NULL, 0),
(191, '', NULL, '', NULL, NULL, 1, NULL, 0),
(192, '', NULL, '', NULL, NULL, 1, NULL, 0),
(193, '', NULL, '', NULL, NULL, 1, NULL, 0),
(194, '', NULL, '', NULL, NULL, 1, NULL, 0),
(195, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(196, 'ewegvg', NULL, 'text', NULL, NULL, 1, NULL, 0),
(197, 'rgerre', NULL, 'text', NULL, NULL, 1, NULL, 2),
(198, '', NULL, 'text_area', NULL, NULL, 1, NULL, 3),
(199, '', NULL, 'text', NULL, NULL, 1, NULL, 4),
(200, '', NULL, 'file', NULL, NULL, 1, NULL, 5),
(201, 'Armando', NULL, 'text', NULL, NULL, 1, NULL, 0),
(202, 'manuel', NULL, 'text_area', NULL, NULL, 1, NULL, 1),
(203, 'julio', NULL, 'text', NULL, NULL, 1, NULL, 3),
(204, 'dambela', NULL, 'radio', NULL, NULL, 1, NULL, 4),
(205, 'betscaba', NULL, 'checkbox', NULL, NULL, 1, NULL, 4),
(206, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(207, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(208, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(209, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(210, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(211, '', NULL, 'text', NULL, NULL, 1, NULL, 2),
(212, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(213, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(214, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(215, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(216, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(217, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(218, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(219, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(220, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(221, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(222, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(223, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(224, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(225, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(226, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(227, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(228, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(229, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(230, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(231, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(232, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(233, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(234, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(235, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(236, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(237, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(238, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(239, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(240, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(241, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(242, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(243, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(244, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(245, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(246, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(247, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(248, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(249, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(250, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(251, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(252, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(253, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(254, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(255, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(256, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(257, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(258, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(259, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(260, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(261, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(262, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(263, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(264, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(265, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(266, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(267, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(268, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(269, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(270, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(271, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(272, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(273, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(274, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(275, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(276, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(277, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(278, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(279, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(280, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(281, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(282, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(283, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(284, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(285, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(286, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(287, '', NULL, 'text', NULL, NULL, 1, NULL, 2),
(288, '', NULL, 'text', NULL, NULL, 1, NULL, 3),
(289, '', NULL, 'text', NULL, NULL, 1, NULL, 4),
(290, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(291, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(292, '', NULL, 'text', NULL, NULL, 1, NULL, 2),
(293, '', NULL, 'text', NULL, NULL, 1, NULL, 3),
(294, '', NULL, 'text', NULL, NULL, 1, NULL, 4),
(295, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(296, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(297, '', NULL, 'text', NULL, NULL, 1, NULL, 2),
(298, '', NULL, 'text', NULL, NULL, 1, NULL, 3),
(299, '', NULL, 'text', NULL, NULL, 1, NULL, 4),
(300, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(301, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(302, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(303, '', NULL, 'text_area', NULL, NULL, 1, NULL, 0),
(304, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(305, '', NULL, 'text_area', NULL, NULL, 1, NULL, 0),
(306, '', NULL, 'text', NULL, NULL, 1, NULL, 1),
(307, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(308, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(309, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(310, '', NULL, 'text', NULL, NULL, 1, NULL, 0),
(311, '', NULL, 'text', NULL, NULL, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `requerimento`
--

CREATE TABLE `requerimento` (
  `id` int(11) NOT NULL,
  `nome` int(30) DEFAULT NULL,
  `formulario_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `estado` int(1) DEFAULT NULL,
  `itens` varchar(600) DEFAULT NULL,
  `data_registo` date NOT NULL,
  `actualizado_por` int(11) DEFAULT NULL,
  `comentario` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(30) DEFAULT NULL,
  `sobrenome` varchar(30) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `numero` int(10) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `data_registo` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `categoria` int(1) NOT NULL DEFAULT '0',
  `estado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `sobrenome`, `telefone`, `email`, `numero`, `password`, `data_registo`, `categoria`, `estado`) VALUES
(1, 'Armando', 'Manuel', '9219999999', 'armanduel24@hotmail.com', 20090066, NULL, '2018-05-29 00:00:00', 1, 1),
(2, 'Filipe', 'dilu', '9219999999', 'filipe@gmail.com', 20120066, NULL, '2018-05-29 00:00:00', 1, 0),
(3, 'Salomao', 'Agora', '9219999999', 'Teste@teste.com', 20120066, NULL, '0000-00-00 00:00:00', 0, 0),
(4, 'Nesto', 'Goncalves', '93199999999', 'teste@email.com', 20120066, 'Teste', '2018-05-30 00:00:00', 0, 1),
(5, 'cambalhota', 'Manuel', '9219999999', 'armanduel24@hotmail.com', 20090066, NULL, '2018-05-29 00:00:00', 0, 1),
(6, 'hionia', 'dilu', '9219999999', 'filipe@gmail.com', 20120066, NULL, '2018-05-29 00:00:00', 0, 0),
(7, 'Salomao', 'tacio', '9219999999', 'Teste@teste.com', 20120066, NULL, '0000-00-00 00:00:00', 0, 0),
(8, 'Joaquim', 'Madeira', '93199999999', 'teste@email.com', 20120066, 'Teste', '2018-05-30 00:00:00', 0, 1),
(9, 'Bom', 'Neves', '9219999999', 'armanduel24@hotmail.com', 20090066, NULL, '2018-05-29 00:00:00', 0, 1),
(10, 'Filipe', 'Mileno', '9219999999', 'filipe@gmail.com', 20120066, NULL, '2018-05-29 00:00:00', 0, 0),
(11, 'Salomao', 'Mateus', '9219999999', 'Teste@teste.com', 20120066, NULL, '0000-00-00 00:00:00', 0, 0),
(12, 'Joaquim', 'Manuel', '93199999999', 'teste@email.com', 20120066, 'Teste', '2018-05-30 00:00:00', 0, 1),
(13, 'Boas', 'Manuel', '9219999999', 'armanduel24@hotmail.com', 20090066, NULL, '2018-05-29 00:00:00', 0, 1),
(14, 'Marta', 'dilu', '9219999999', 'filipe@gmail.com', 20120066, NULL, '2018-05-29 00:00:00', 0, 0),
(15, 'Salomao', 'Mateus', '9219999999', 'Teste@teste.com', 20120066, NULL, '0000-00-00 00:00:00', 0, 0),
(16, 'Outro', 'Manuel', '93199999999', 'teste@email.com', 20120066, 'Teste', '2018-05-30 00:00:00', 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actividades`
--
ALTER TABLE `actividades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formulario`
--
ALTER TABLE `formulario`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_itens`
--
ALTER TABLE `form_itens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requerimento`
--
ALTER TABLE `requerimento`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actividades`
--
ALTER TABLE `actividades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formulario`
--
ALTER TABLE `formulario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form_itens`
--
ALTER TABLE `form_itens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=312;

--
-- AUTO_INCREMENT for table `requerimento`
--
ALTER TABLE `requerimento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
